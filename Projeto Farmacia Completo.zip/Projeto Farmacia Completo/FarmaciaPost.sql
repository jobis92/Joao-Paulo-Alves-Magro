﻿CREATE TABLE Users (
  idUsers serial  NOT NULL ,
  senha VARCHAR(45) NOT NULL,
  n_login VARCHAR(45) NOT NULL,
  PRIMARY KEY(idUsers)
);

CREATE TABLE DadosPaciente (
  idDadosPaciente serial not null,
  endereco VARCHAR(255) NOT NULL,
  telefone INTEGER NULL,
  cidade VARCHAR(45) NOT NULL,
  estado VARCHAR(45) NOT NULL,
  profissao VARCHAR(45) NULL,
  email VARCHAR(45) NULL,
  PRIMARY KEY(idDadosPaciente)
);

CREATE TABLE Medicamento (
  idMedicamento serial not null,
  nome_medicam VARCHAR(255) NOT NULL,
  data_vencimento DATE NOT NULL,
  qtd_estoque INTEGER NOT NULL,
  preco float NOT NULL,
  PRIMARY KEY(idMedicamento)
);

CREATE TABLE Farmaceuticos (
  idFarmaceuticos serial not null,  
  nome VARCHAR(255) NOT NULL,
  telefone VARCHAR(255) NULL,
  CRF VARCHAR(20) NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  CPF VARCHAR(11) NOT NULL,
  cidade VARCHAR(45) NOT NULL,
  estado VARCHAR(20) NOT NULL,
  email VARCHAR(255) NULL,
 
	constraint pk_Farmaceuticos primary key (idFarmaceuticos),
	Users_idUsers int constraint fk_Farmaceuticos_Users
	references Users 
	on delete restrict
	on update cascade
  
);

CREATE TABLE Receitas (
  idReceitas serial ,
  nome_paciente VARCHAR(255) NOT NULL,
  cpf_paciente VARCHAR(11) NOT NULL,
  nome_medico VARCHAR(255) NOT NULL,
  CRM VARCHAR(20) NOT NULL,
  medicamento VARCHAR(255) NOT NULL,
  qtd_medicam INTEGER  NOT NULL,
  
  constraint pk_Receitas primary key (idReceitas),
  
  Medicamento_idMedicamento int constraint fk_Receitas_Medicamento
		references Medicamento
		on delete restrict
		on update cascade
		
 );

CREATE TABLE Paciente (
  idPaciente serial NOT NULL ,
  nome VARCHAR(255) NOT NULL,
  cpf VARCHAR(11) NOT NULL,
  sexo VARCHAR(20) NOT NULL,
  idade INTEGER  NOT NULL,
  constraint pk_Paciente primary key (idPaciente),
   DadosPaciente_idDadosPaciente int constraint fk_Paciente_DadosPaciente
		references DadosPaciente
		on delete restrict
		on update cascade,
		
   Farmaceuticos_idFarmaceuticos int constraint fk_Paciente_Farmaceuticos
		references Farmaceuticos
		on delete restrict
		on update cascade,

   Receitas_idReceitas int constraint fk_Paciente_Receitas
		references Receitas
		on delete restrict
		on update cascade
 
);


--------------------------REPLICAÇÃO USERS--------------------------------


create or replace function replica_dados_users() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into users (idUsers, senha, n_login) values (' ||
	      new.idUsers || ', ''' || new.senha || ''', ''' || new.n_login || ''')');
	   raise notice 'INSERT USERS OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update users set idUsers = ' || new.idUsers || ', senha = ''' ||
	   new.senha || ''', n_login = ''' || new.n_login || ''' where idUsers = ' || old.idUsers || '');
	   raise notice 'UPDATE USERS OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from users where idUsers = ' || old.idUsers || '');
	   raise notice 'DELETE USERS OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_users after insert or update or delete on users for each row 
   execute procedure replica_dados_users();


--------------------------AUDITORIA USERS--------------------------------
			
create or replace function auditoria_users()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idusers ||','|| new.senha||','|| new.n_login;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idusers ||','|| new.senha||','|| new.n_login;
		dados_antigos:= old.idusers||','||old.senha||','||old.n_login;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idusers||','||old.senha||','||old.n_login;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_users ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_users after delete or insert or update on users for each row execute procedure auditoria_users();



--------------------------- REPLICAÇÃO DADOS_PACIENTES -------------------------

create or replace function replica_dados_dadospaciente() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into dadospaciente (idDadosPaciente, endereco, telefone, cidade, estado, profissao, email) values (' ||
	      new.idDadosPaciente || ', ''' || new.endereco || ''', ''' || new.telefone || ''', ''' || new.cidade || ''', ''' || new.estado || ''',
	      ''' || new.profissao || ''', ''' || new.email || ''')');
	   raise notice 'INSERT DADOS PACIENTE OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update dadospaciente set idDadosPaciente = ' || new.idDadosPaciente || ', endereco = ''' ||
	   new.endereco || ''', telefone = ''' || new.telefone || ''', cidade = ''' || new.cidade || ''',
	   estado = ''' || new.estado || ''', profissao = ''' || new.profissao || ''', email = ''' || new.email || ''' where idDadosPaciente = ' || old.idDadosPaciente || '');
	   raise notice 'UPDATE DADOS PACIENTE OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from dadospaciente where idDadosPaciente = ' || old.idDadosPaciente || '');
	   raise notice 'DELETE DADOS PACIENTE OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_dadosPaciente after insert or update or delete on dadospaciente for each row 
   execute procedure replica_dados_dadospaciente();


--------------------------AUDITORIA DADOS_PACIENTE --------------------------------

create or replace function auditoria_dadospaciente()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idDadosPaciente ||','|| new.endereco||','|| new.telefone || ',' || new.cidade 
		|| ',' || new.estado || ',' || new.profissao || ',' || new.email;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idDadosPaciente ||','|| new.endereco||','|| new.telefone || ',' || new.cidade 
		|| ',' || new.estado || ',' || new.profissao || ',' || new.email;
		dados_antigos:= old.idDadosPaciente||','||old.endereco||','||old.telefone||','||old.cidade||','||old.estado
		||','||old.profissao||','||old.email;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idDadosPaciente||','||old.endereco||','||old.telefone||','||old.cidade||','||old.estado
		||','||old.profissao||','||old.email;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_dadospaciente ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_dadospaciente after delete or insert or update on dadospaciente for each row execute procedure auditoria_dadospaciente();

------------------------- REPLICAÇÃO MEDICAMENTO -------------------------

create or replace function replica_dados_medicamento() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into medicamento (idMedicamento, nome_medicam, data_vencimento, qtd_estoque, preco) 
       values (' || new.idMedicamento || ', ''' || new.nome_medicam || ''', ''' || new.data_vencimento || ''', ''' || new.qtd_estoque || ''',
        ''' || new.preco || ''')');
	   raise notice 'INSERT MEDICAMENTOS OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update medicamento set idMedicamento = ' || new.idMedicamento || ', nome_medicam = ''' ||
	   new.nome_medicam || ''', data_vencimento = ''' || new.data_vencimento || ''', qtd_estoque = ''' || new.qtd_estoque || ''',
	   preco = ''' || new.preco|| '''  where idMedicamento = ' || old.idMedicamento || '');
	   raise notice 'UPDATE MEDICAMENTOS OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from Medicamento where idMedicamento = ' || old.idMedicamento || '');
	   raise notice 'DELETE MEDICAMENTOS OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_Medicamento after insert or update or delete on Medicamento for each row 
   execute procedure replica_dados_medicamento();

   
--------------------------AUDITORIA MEDICAMENTO --------------------------------

create or replace function auditoria_Medicamento()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idMedicamento ||','|| new.nome_medicam||','|| new.data_vencimento || ',' || new.qtd_estoque 
		|| ',' || new.preco;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idMedicamento ||','|| new.nome_medicam||','|| new.data_vencimento || ',' || new.qtd_estoque 
		|| ',' || new.preco;
		dados_antigos:= old.idMedicamento||','||old.nome_medicam||','||old.data_vencimento||','||old.qtd_estoque||','||old.preco;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idMedicamento||','||old.nome_medicam||','||old.data_vencimento||','||old.qtd_estoque||','||old.preco;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_medicamento ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_medicamento after delete or insert or update on medicamento for each row execute procedure auditoria_medicamento();



------------------------- REPLICAÇÃO FARMACEUTICOS -------------------------

create or replace function replica_dados_farmaceuticos() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into Farmaceuticos (idFarmaceuticos, nome ,telefone, CRF, endereco, CPF,
        cidade, estado, email,Users_idUsers) 
       values (' || new.idFarmaceuticos || ', ''' || new.nome || ''', ''' || new.telefone || ''', ''' || new.CRF || ''',
       ''' || new.endereco || ''',''' || new.CPF || ''', ''' || new.cidade || ''', ''' || new.estado || ''', ''' || new.email || ''',
	   ''' || new.Users_idUsers || ''')');
	   raise notice 'INSERT FARMACEUTICOS OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update farmaceuticos set idFarmaceuticos = ' || new.idFarmaceuticos || ', nome = ''' || 
       new.nome || ''', telefone = ''' || new.telefone || ''', CRF = ''' || new.CRF || ''' ,endereco = ''' || new.endereco || ''', CPF = ''' || new.CPF || '''
       cidade = ''' || new.cidade || ''', estado = ''' || new.estado || ''', email = ''' || new.email || ''' , Users_idUsers = ''' || new.Users_idUsers || '''
	    where idfarmaceuticos = ' || old.idFarmaceuticos || '');
	   raise notice 'UPDATE FARMACEUTICOS OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from farmaceuticos where idFarmaceuticos = ' || old.idFarmaceuticos || '');
	   raise notice 'DELETE USERS OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_farmaceuticos after insert or update or delete on farmaceuticos for each row 
   execute procedure replica_dados_farmaceuticos();



--------------------------AUDITORIA FARMACEUTICOS --------------------------------

create or replace function auditoria_farmaceuticos()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idfarmaceuticos ||','|| new.nome||','|| new.telefone||','|| new.CRF||','|| new.endereco ||','|| new.CPF
		||','|| new.cidade||','|| new.estado||','|| new.email ||','|| new.Users_idUsers ;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idfarmaceuticos ||','|| new.nome||','|| new.telefone||','|| new.CRF||','|| new.endereco ||','|| new.CPF
		||','|| new.cidade||','|| new.estado||','|| new.email ||','|| new.Users_idUsers ;
		dados_antigos:= old.idfarmaceuticos ||','|| old.nome||','|| old.telefone||','|| old.CRF||','|| old.endereco ||','|| old.CPF
		||','|| old.cidade||','|| old.estado||','|| old.email ||','|| old.Users_idUsers;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idfarmaceuticos ||','|| old.nome||','|| old.telefone||','|| old.CRF||','|| old.endereco ||','|| old.CPF
		||','|| old.cidade||','|| old.estado||','|| old.email ||','|| old.Users_idUsers;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_farmaceuticos ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_farmaceuticos after delete or insert or update on farmaceuticos
for each row execute procedure auditoria_farmaceuticos();

------------------------- REPLICAÇÃO RECEITAS -------------------------

create or replace function replica_dados_receitas() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into receitas (idReceitas, nome_paciente, cpf_paciente, nome_medico, CRM, medicamento , qtd_medicam, Medicamento_idMedicamento) 
       values (' || new.idReceitas || ', ''' || new.nome_paciente || ''', ''' || new.cpf_paciente || ''', ''' || new.nome_medico || ''',
        ''' || new.CRM || ''', ''' || new.medicamento || ''' ,''' || new.qtd_medicam || ''', ''' || new. Medicamento_idMedicamento || ''')');
	   raise notice 'INSERT RECEITAS OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update receitas set idReceitas = ' || new.idReceitas || ', nome_paciente = ''' ||
	   new.nome_paciente || ''', cpf_paciente = ''' || new.cpf_paciente || ''', nome_medico = ''' || new.nome_medico || ''',
	   CRM = ''' || new.CRM|| ''', medicamento = ''' || new.medicamento|| ''', qtd_medicam = ''' || new.qtd_medicam|| ''', 
	    Medicamento_idMedicamento = ''' || new. Medicamento_idMedicamento || '''  where idReceitas = ' || old.idReceitas || '');
	   raise notice 'UPDATE RECEITAS OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from Receitas where idReceitas = ' || old.idReceitas || '');
	   raise notice 'DELETE RECEITAS OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_Receitas after insert or update or delete on Receitas for each row 
   execute procedure replica_dados_Receitas();

--------------------------AUDITORIA RECEITAS --------------------------------

create or replace function auditoria_Receitas()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idReceitas ||','|| new.nome_paciente||','|| new.cpf_paciente || ',' || new.nome_medico 
		|| ',' || new.CRM|| ',' || new.medicamento || ',' || new.qtd_medicam ||','|| new. Medicamento_idMedicamento ;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idReceitas ||','|| new.nome_paciente||','|| new.cpf_paciente || ',' || new.nome_medico 
		|| ',' || new.CRM|| ',' || new.medicamento || ',' || new.qtd_medicam ||','|| new. Medicamento_idMedicamento ;
		dados_antigos:= old.idReceitas ||','|| old.nome_paciente ||','|| old.pcf_paciente ||','|| old.nome_medico ||','||old.CRM ||','||old.medicamento
		||','||old.qtd_medicam ||','||old. Medicamento_idMedicamento;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idReceitas ||','|| old.nome_paciente ||','|| old.pcf_paciente ||','|| old.nome_medico ||','||old.CRM ||','||old.medicamento
		||','||old.qtd_medicam ||','||old. Medicamento_idMedicamento;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_receitas ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_receitas after delete or insert or update on receitas for each row execute procedure auditoria_receitas();

------------------------- REPLICAÇÃO PACIENTE -------------------------

create or replace function replica_dados_paciente() returns trigger as
$$

declare

dados_banco varchar(300);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_replica user=postgres password=root port=5432';

if (TG_OP = 'INSERT') THEN
       perform dblink_exec(dados_banco, 'insert into paciente (idpaciente, nome ,cpf, sexo, idade,DadosPaciente_idDadosPaciente,
       Farmaceuticos_idFarmaceuticos, Receitas_idReceitas) 
       values (' || new.idpaciente || ', ''' || new.nome || ''', ''' || new.cpf|| ''', ''' || new.sexo || ''',
       ''' || new.idade || ''', ''' || new.DadosPaciente_idDadosPaciente || ''', ''' || new.Farmaceuticos_idFarmaceuticos || ''', ''' || new.Receitas_idReceitas || ''')');
	   raise notice 'INSERT PACIENTE OK';
   end if;
   if (TG_OP = 'UPDATE') THEN
       perform dblink_exec(dados_banco, 'update paciente set idpaciente = ' || new.idpaciente || ', nome = ''' ||
       new.nome || ''', cpf = ''' || new.cpf || ''', sexo = ''' || new.sexo || ''' ,idade = ''' || new.idade || ''',
       DadosPaciente_idDadosPaciente = ''' || new.DadosPaciente_idDadosPaciente || ''', Farmaceuticos_idFarmaceuticos = ''' || new.Farmaceuticos_idFarmaceuticos || ''',
        Receitas_idReceitas = ''' || new.Receitas_idReceitas || '''  where idpaciente = ' || old.idpaciente || '');
	   raise notice 'UPDATE PACIENTE OK';
   end if;
   if (TG_OP = 'DELETE') THEN
       perform dblink_exec(dados_banco, 'delete from paciente where idpaciente = ' || old.idpaciente || '');
	   raise notice 'DELETE PACIENTE OK';
   end if;
 
   return null;
end;
$$
language plpgsql;

create trigger replicacao_paciente after insert or update or delete on paciente for each row 
   execute procedure replica_dados_paciente();

--------------------------AUDITORIA PACIENTE --------------------------------

create or replace function auditoria_paciente ()returns trigger as
$$
declare

	dados_novos varchar(500);
	dados_antigos varchar(500);
	dados_banco varchar(500);

begin

dados_banco := 'hostaddr=127.0.0.1 dbname=farmacia_auditoria user=postgres password=root port=5432';

if (TG_OP = 'INSERT') then
		dados_novos:= new.idpaciente ||','|| new.nome||','|| new.cpf||','|| new.sexo||','|| new.idade
		||','|| new.DadosPaciente_idDadosPaciente||','|| new.Farmaceuticos_idFarmaceuticos||','|| new.Receitas_idReceitas;
		dados_antigos:= 'Dados novos, sem registros antigos';
	end if;
	if (TG_OP = 'UPDATE') then
		dados_novos:= new.idpaciente ||','|| new.nome||','|| new.cpf||','|| new.sexo||','|| new.idade
		||','|| new.DadosPaciente_idDadosPaciente||','|| new.Farmaceuticos_idFarmaceuticos||','|| new.Receitas_idReceitas;
		dados_antigos:= old.idpaciente ||','|| old.nome||','|| old.cpf||','|| old.sexo||','|| old.idade
		||','|| old.DadosPaciente_idDadosPaciente||','|| old.Farmaceuticos_idFarmaceuticos||','|| old.Receitas_idReceitas;
	end if;
	if (TG_OP = 'DELETE')then
		dados_antigos:= old.idpaciente ||','|| old.nome||','|| old.cpf||','|| old.sexo||','|| old.idade
		||','|| old.DadosPaciente_idDadosPaciente||','|| old.Farmaceuticos_idFarmaceuticos||','|| old.Receitas_idReceitas;
		dados_novos:= ' Sem atualizações para este registro!, exclusão dos mesmos';
	end if;

	perform	dblink_exec(dados_banco, 'insert into auditoria_farmaceuticos ( endereco_ip, nome_user, data_modificacao, ' ||
		'dados_antigos, dados_novos, operacao, executado_por, nome_tabela, nome_gatilho) values (''' || 
		inet_client_addr() || ''',''' || user || ''',''' || now() || ''',''' || dados_antigos || ''',''' || 
		dados_novos || ''',''' || TG_OP || ''',''' || TG_RELID || ''',''' || TG_RELNAME || ''',''' || TG_NAME || ''')');
	return null;
end;
$$
language 'plpgsql';

create trigger aud_paciente after delete or insert or update on paciente
for each row execute procedure auditoria_paciente();