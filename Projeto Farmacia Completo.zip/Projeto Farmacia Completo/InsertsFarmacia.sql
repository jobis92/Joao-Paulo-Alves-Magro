﻿--------------INSERTS USERS-----------

insert into users values (1, 'senha1' ,'usuario1');
insert into users values (2, 'senha2' ,'usuario2');
insert into users values (3, 'senha3' ,'usuario3');
insert into users values (4, 'senha4' ,'usuario4');
insert into users values (5, 'senha5' ,'usuario5');
insert into users values (6, 'senha6' ,'usuario6');
insert into users values (7, 'senha7' ,'usuario7');
insert into users values (8, 'senha8' ,'usuario8');
insert into users values (9, 'senha9' ,'usuario9');
insert into users values (10, 'senha10' ,'usuario10');
insert into users values (11, 'senha11' ,'usuario11');
insert into users values (12, 'senha12' ,'usuario12');
insert into users values (13, 'senha13' ,'usuario13');
insert into users values (14, 'senha14' ,'usuario14');
insert into users values (15, 'senha15' ,'usuario15');
insert into users values (16, 'senha16' ,'usuario16');
insert into users values (17, 'senha17' ,'usuario17');
insert into users values (18, 'senha18' ,'usuario18');
insert into users values (19, 'senha19' ,'usuario19');
insert into users values (20, 'senha20' ,'usuario20');

select * from users

--------------INSERTS DADOS PACIENTE-----------

insert into dadospaciente values (1,'Rua 1', '11111111', 'cidade1' , 'a', 'autonomo1', 'email1@teste.com');
insert into dadospaciente values (2,'Rua 2', '22222222', 'cidade2' , 'b', 'autonomo2', 'email2@teste.com');
insert into dadospaciente values (3,'Rua 3', '33333333', 'cidade3' , 'c', 'autonomo3', 'email3@teste.com');
insert into dadospaciente values (4,'Rua 4', '44444444', 'cidade4' , 'd', 'autonomo4', 'email4@teste.com');
insert into dadospaciente values (5,'Rua 5', '55555555', 'cidade5' , 'e', 'autonomo5', 'email5@teste.com');
insert into dadospaciente values (6,'Rua 6', '66666666', 'cidade6' , 'f', 'autonomo6', 'email6@teste.com');
insert into dadospaciente values (7,'Rua 7', '77777777', 'cidade7' , 'g', 'autonomo7', 'email7@teste.com');
insert into dadospaciente values (8,'Rua 8', '88888888', 'cidade8' , 'h', 'autonomo8', 'email8@teste.com');
insert into dadospaciente values (9,'Rua 9', '99999999', 'cidade9' , 'i', 'autonomo9', 'email9@teste.com');
insert into dadospaciente values (10,'Rua 10', '11111110', 'cidade10' , 'j', 'autonomo10', 'email10@teste.com');
insert into dadospaciente values (11,'Rua 11', '11110111', 'cidade11' , 'k', 'autonomo11', 'email11@teste.com');
insert into dadospaciente values (12,'Rua 12', '11111112', 'cidade12' , 'l', 'autonomo12', 'email12@teste.com');
insert into dadospaciente values (13,'Rua 13', '11111113', 'cidade13' , 'm', 'autonomo13', 'email13@teste.com');
insert into dadospaciente values (14,'Rua 14', '11111114', 'cidade14' , 'n', 'autonomo14', 'email14@teste.com');
insert into dadospaciente values (15,'Rua 15', '11111115', 'cidade15' , 'o', 'autonomo15', 'email15@teste.com');
insert into dadospaciente values (16,'Rua 16', '11111116', 'cidade16' , 'p', 'autonomo16', 'email16@teste.com');
insert into dadospaciente values (17,'Rua 17', '11111117', 'cidade17' , 'q', 'autonomo17', 'email17@teste.com');
insert into dadospaciente values (18,'Rua 18', '11111118', 'cidade18' , 'r', 'autonomo18', 'email18@teste.com');
insert into dadospaciente values (19,'Rua 19', '11111119', 'cidade19' , 's', 'autonomo19', 'email19@teste.com');
insert into dadospaciente values (20,'Rua 20', '11111120', 'cidade20' , 't', 'autonomo20', 'email20@teste.com');

select * from dadospaciente
	

--------------INSERTS MEDICAMENTO-----------

insert into medicamento values (1, 'Remedio1', '01-01-2019', 1, 1.00);
insert into medicamento values (2, 'Remedio2', '02-01-2019', 2, 2.00);
insert into medicamento values (3, 'Remedio3', '03-01-2019', 3, 3.00);
insert into medicamento values (4, 'Remedio4', '04-01-2019', 4, 4.00);
insert into medicamento values (5, 'Remedio5', '05-01-2019', 5, 5.00);
insert into medicamento values (6, 'Remedio6', '06-01-2019', 6, 6.00);
insert into medicamento values (7, 'Remedio7', '07-01-2019', 7, 7.00);
insert into medicamento values (8, 'Remedio8', '08-01-2019', 8, 8.00);
insert into medicamento values (9, 'Remedio9', '09-01-2019', 9, 9.00);
insert into medicamento values (10, 'Remedio10', '10-01-2019', 10, 10.00);
insert into medicamento values (11, 'Remedio11', '11-01-2019', 11, 11.00);
insert into medicamento values (12, 'Remedio12', '12-01-2019', 12, 12.00);
insert into medicamento values (13, 'Remedio13', '13-01-2019', 13, 13.00);
insert into medicamento values (14, 'Remedio14', '14-01-2019', 14, 14.00);
insert into medicamento values (15, 'Remedio15', '15-01-2019', 15, 15.00);
insert into medicamento values (16, 'Remedio16', '16-01-2019', 16, 16.00);
insert into medicamento values (17, 'Remedio17', '17-01-2019', 17, 17.00);
insert into medicamento values (18, 'Remedio18', '18-01-2019', 18, 18.00);
insert into medicamento values (19, 'Remedio19', '19-01-2019', 19, 19.00);
insert into medicamento values (20, 'Remedio20', '20-01-2019', 20, 20.00);

select * from medicamento;

--------------INSERTS FARMACEUTICOS-----------

insert into farmaceuticos values (1, 'farmaceutico1' , '11111111', 'crf1', 'av.1','11111111111','guaxupe1', 'estado1', 'farmaceutico1@farmacia.com',1 );
insert into farmaceuticos values (2, 'farmaceutico2' , '22222222', 'crf2', 'av.2','22222222222','guaxupe2', 'estado2', 'farmaceutico2@farmacia.com',2 );
insert into farmaceuticos values (3, 'farmaceutico3' , '33333333', 'crf3', 'av.3','33333333333','guaxupe3', 'estado3', 'farmaceutico3@farmacia.com',3 );
insert into farmaceuticos values (4, 'farmaceutico4' , '44444444', 'crf4', 'av.4','44444444444','guaxupe4', 'estado4', 'farmaceutico4@farmacia.com',4 );
insert into farmaceuticos values (5, 'farmaceutico5' , '55555555', 'crf5', 'av.5','55555555555','guaxupe5', 'estado5', 'farmaceutico5@farmacia.com',5 );
insert into farmaceuticos values (6, 'farmaceutico6' , '66666666', 'crf6', 'av.6','66666666666','guaxupe6', 'estado6', 'farmaceutico6@farmacia.com',6 );
insert into farmaceuticos values (7, 'farmaceutico7' , '77777777', 'crf7', 'av.7','77777777777','guaxupe7', 'estado7', 'farmaceutico7@farmacia.com',7 );
insert into farmaceuticos values (8, 'farmaceutico8' , '88888888', 'crf8', 'av.8','88888888888','guaxupe8', 'estado8', 'farmaceutico8@farmacia.com',8 );
insert into farmaceuticos values (9, 'farmaceutico9' , '99999999', 'crf9', 'av.9','99999999999','guaxupe9', 'estado9', 'farmaceutico9@farmacia.com',9 );
insert into farmaceuticos values (10, 'farmaceutico10' , '11111110', 'crf10', 'av.10','11111111110','guaxupe10', 'estado10', 'farmaceutico10@farmacia.com',10 );
insert into farmaceuticos values (11, 'farmaceutico11' , '11111101', 'crf11', 'av.11','11111111101','guaxupe11', 'estado11', 'farmaceutico11@farmacia.com',11 );
insert into farmaceuticos values (12, 'farmaceutico12' , '11111112', 'crf12', 'av.12','11111111112','guaxupe12', 'estado12', 'farmaceutico12@farmacia.com',12 );
insert into farmaceuticos values (13, 'farmaceutico13' , '11111113', 'crf13', 'av.13','11111111113','guaxupe13', 'estado13', 'farmaceutico13@farmacia.com',13 );
insert into farmaceuticos values (14, 'farmaceutico14' , '11111114', 'crf14', 'av.14','11111111114','guaxupe14', 'estado14', 'farmaceutico14@farmacia.com',14 );
insert into farmaceuticos values (15, 'farmaceutico15' , '11111115', 'crf15', 'av.15','11111111115','guaxupe15', 'estado15', 'farmaceutico15@farmacia.com',15 );
insert into farmaceuticos values (16, 'farmaceutico16' , '11111116', 'crf16', 'av.16','11111111161','guaxupe16', 'estado16', 'farmaceutico16@farmacia.com',16 );
insert into farmaceuticos values (17, 'farmaceutico17' , '11111117', 'crf17', 'av.17','11111111117','guaxupe17', 'estado17', 'farmaceutico17@farmacia.com',17 );
insert into farmaceuticos values (18, 'farmaceutico18' , '11111118', 'crf18', 'av.18','11111111118','guaxupe18', 'estado18', 'farmaceutico18@farmacia.com',18 );
insert into farmaceuticos values (19, 'farmaceutico19' , '11111119', 'crf19', 'av.19','11111111119','guaxupe19', 'estado19', 'farmaceutico19@farmacia.com',19 );
insert into farmaceuticos values (20, 'farmaceutico20' , '11111120', 'crf20', 'av.20','11111111120','guaxupe20', 'estado20', 'farmaceutico20@farmacia.com',20 );


select * from farmaceuticos
	
--------------INSERTS RECEITAS-----------
insert into receitas values (1, 'joao1', '11111111111', 'medico1', 'crm1','remedio1',1,1);
insert into receitas values (2, 'joao2', '22222222222', 'medico2', 'crm2','remedio2',2,2);
insert into receitas values (3, 'joao3', '33333333333', 'medico3', 'crm3','remedio3',3,3);
insert into receitas values (4, 'joao4', '44444444444', 'medico4', 'crm4','remedio4',4,4);
insert into receitas values (5, 'joao5', '55555555555', 'medico5', 'crm5','remedio5',5,5);
insert into receitas values (6, 'joao6', '66666666666', 'medico6', 'crm6','remedio6',6,6);
insert into receitas values (7, 'joao7', '77777777777', 'medico7', 'crm7','remedio7',7,7);
insert into receitas values (8, 'joao8', '88888888888', 'medico8', 'crm8','remedio8',8,8);
insert into receitas values (9, 'joao9', '99999999999', 'medico9', 'crm9','remedio9',9,9);
insert into receitas values (10, 'joao10', '11111111110', 'medico10', 'crm10','remedio10',10,10);
insert into receitas values (11, 'joao11', '11111111111', 'medico11', 'crm11','remedio11',11,11);
insert into receitas values (12, 'joao12', '11111111112', 'medico12', 'crm12','remedio12',12,12);
insert into receitas values (13, 'joao13', '11111111113', 'medico13', 'crm13','remedio13',13,13);
insert into receitas values (14, 'joao14', '11111111114', 'medico14', 'crm14','remedio14',14,14);
insert into receitas values (15, 'joao15', '11111111115', 'medico15', 'crm15','remedio15',15,15);
insert into receitas values (16, 'joao16', '11111111116', 'medico16', 'crm16','remedio16',16,16);
insert into receitas values (17, 'joao17', '11111111117', 'medico17', 'crm17','remedio17',17,17);
insert into receitas values (18, 'joao18', '11111111118', 'medico18', 'crm18','remedio18',18,18);
insert into receitas values (19, 'joao19', '11111111119', 'medico19', 'crm19','remedio19',19,19);
insert into receitas values (20, 'joao20', '11111111120', 'medico20', 'crm20','remedio20',20,20);

select * from receitas

--------------INSERTS PACIENTE-----------

insert into paciente values (1,'paciente1','11111111111','masc',1,1,1,1);
insert into paciente values (2,'paciente2','22222222222','masc',2,2,2,2);
insert into paciente values (3,'paciente3','33333333333','masc',3,3,3,3);
insert into paciente values (4,'paciente4','44444444444','masc',4,4,4,4);
insert into paciente values (5,'paciente5','55555555555','masc',5,5,5,5);
insert into paciente values (6,'paciente6','66666666666','masc',6,6,6,6);
insert into paciente values (7,'paciente7','77777777777','masc',7,7,7,7);
insert into paciente values (8,'paciente8','88888888888','masc',8,8,8,8);
insert into paciente values (9,'paciente9','99999999999','masc',9,9,9,9);
insert into paciente values (10,'paciente10','11111111110','masc',10,10,10,10);
insert into paciente values (11,'paciente11','11111111111','masc',11,11,11,11);
insert into paciente values (12,'paciente12','11111111112','masc',12,12,12,12);
insert into paciente values (13,'paciente13','11111111113','masc',13,13,13,13);
insert into paciente values (14,'paciente14','11111111114','masc',14,14,14,14);
insert into paciente values (15,'paciente15','11111111115','masc',15,15,15,15);
insert into paciente values (16,'paciente16','11111111116','masc',16,16,16,16);
insert into paciente values (17,'paciente17','11111111117','masc',17,17,17,17);
insert into paciente values (18,'paciente18','11111111118','masc',18,18,18,18);
insert into paciente values (19,'paciente19','11111111119','masc',19,19,19,19);
insert into paciente values (20,'paciente20','11111111120','masc',20,20,20,20);

select * from paciente