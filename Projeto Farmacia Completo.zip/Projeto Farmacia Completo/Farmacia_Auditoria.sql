﻿create table auditoria_users
(
id_aud_user serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_users primary key (id_aud_user)
 );


 create table auditoria_farmaceuticos
(
id_aud_farmaceuticos serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_farmaceuticos primary key (id_aud_farmaceuticos)
 );

 create table auditoria_paciente
(
id_aud_paciente serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_paciente primary key (id_aud_paciente)
 );


 create table auditoria_dadospaciente
(
id_aud_dadospaciente serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_dadospaciente primary key (id_aud_dadospaciente)
 );

 create table auditoria_receitas
(
id_aud_receitas serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_receitas primary key (id_aud_receitas)
 );

 create table auditoria_medicamento
(
id_aud_medicamento serial, 
endereco_ip varchar (30), 
nome_user varchar (50), 
data_modificacao varchar (30),
dados_antigos varchar (300),
dados_novos varchar (300),
operacao varchar (50),
executado_por varchar (25),
nome_tabela varchar (30), 
nome_gatilho varchar (30), 
 
 constraint pk_auditoria_medicamento primary key (id_aud_medicamento)
 );

select * from auditoria_users;
select * from auditoria_farmaceuticos; 
select * from auditoria_paciente;
select * from auditoria_dadospaciente;
select * from auditoria_receitas;
select * from auditoria_medicamento;




 