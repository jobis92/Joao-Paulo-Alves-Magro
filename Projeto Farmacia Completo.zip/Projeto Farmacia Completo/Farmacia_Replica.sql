﻿CREATE TABLE Users (
  idUsers serial  NOT NULL ,
  senha VARCHAR(45) NOT NULL,
  n_login VARCHAR(45) NOT NULL,
  PRIMARY KEY(idUsers)
);

CREATE TABLE DadosPaciente (
  idDadosPaciente serial not null,
  endereco VARCHAR(255) NOT NULL,
  telefone INTEGER NULL,
  cidade VARCHAR(45) NOT NULL,
  estado VARCHAR(45) NOT NULL,
  profissao VARCHAR(45) NULL,
  email VARCHAR(45) NULL,
  PRIMARY KEY(idDadosPaciente)
);

CREATE TABLE Medicamento (
  idMedicamento serial not null,
  nome_medicam VARCHAR(255) NOT NULL,
  data_vencimento DATE NOT NULL,
  qtd_estoque INTEGER NOT NULL,
  preco float NOT NULL,
  PRIMARY KEY(idMedicamento)
);

CREATE TABLE Farmaceuticos (
  idFarmaceuticos serial not null,  
  nome VARCHAR(255) NOT NULL,
  telefone VARCHAR(255) NULL,
  CRF VARCHAR(20) NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  CPF VARCHAR(11) NOT NULL,
  cidade VARCHAR(45) NOT NULL,
  estado VARCHAR(20) NOT NULL,
  email VARCHAR(255) NULL,
 
	constraint pk_Farmaceuticos primary key (idFarmaceuticos),
	Users_idUsers int constraint fk_Farmaceuticos_Users
	references Users 
	on delete restrict
	on update cascade
  
);

CREATE TABLE Receitas (
  idReceitas serial ,
  nome_paciente VARCHAR(255) NOT NULL,
  cpf_paciente VARCHAR(11) NOT NULL,
  nome_medico VARCHAR(255) NOT NULL,
  CRM VARCHAR(20) NOT NULL,
  medicamento VARCHAR(255) NOT NULL,
  qtd_medicam INTEGER  NOT NULL,
  
  constraint pk_Receitas primary key (idReceitas),
  
  Medicamento_idMedicamento int constraint fk_Receitas_Medicamento
		references Medicamento
		on delete restrict
		on update cascade
		
 );

CREATE TABLE Paciente (
  idPaciente serial NOT NULL ,
  nome VARCHAR(255) NOT NULL,
  cpf VARCHAR(11) NOT NULL,
  sexo VARCHAR(20) NOT NULL,
  idade INTEGER  NOT NULL,
  constraint pk_Paciente primary key (idPaciente),
   DadosPaciente_idDadosPaciente int constraint fk_Paciente_DadosPaciente
		references DadosPaciente
		on delete restrict
		on update cascade,
		
   Farmaceuticos_idFarmaceuticos int constraint fk_Paciente_Farmaceuticos
		references Farmaceuticos
		on delete restrict
		on update cascade,

   Receitas_idReceitas int constraint fk_Paciente_Receitas
		references Receitas
		on delete restrict
		on update cascade
 
);

select * from users;
select * from dadospaciente;
select * from medicamento;
select * from farmaceuticos;
select * from receitas;
select * from paciente;